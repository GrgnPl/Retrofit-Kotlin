package com.example.retrofitkullanm

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitClient {

    companion object
    {
    fun getClient(baseUrl:String):Retrofit{
        return Retrofit.Builder()
            .baseUrl(baseUrl) //base url belirledik http://grgnpl.com adresi
            .addConverterFactory(GsonConverterFactory.create()) // json parse ediliyor
            .build()
    }
    }
}