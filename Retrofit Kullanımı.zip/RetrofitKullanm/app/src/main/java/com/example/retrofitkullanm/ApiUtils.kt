package com.example.retrofitkullanm

import retrofit2.create

class ApiUtils {
    companion object //Bu fonksiyonla interface'e erişim sağlıyoruz.
    {
    val BASE_URL = "http://grgnpl.com/"

    fun getKisilerDaoInterface():KisilerDaoInterface
    {
    return RetrofitClient.getClient(BASE_URL).create(KisilerDaoInterface::class.java) //Static olan Retrofit Client sınıfındaki getClient Fonksiyonunu çağırdık, yukarıda oluşturmuş olduğumuz Baseurl'i mizi de atadık.
    }
    }
}