package com.example.retrofitkullanm

import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface KisilerDaoInterface {
    //Web Servislerimizdeki metotları burada kullanacağız

    @POST("delete_kisiler.php") //Base URL'mizin sonraki devamı
    @FormUrlEncoded
    fun kisiSil(@Field("kisi_id") kisi_id:Int):Call<CRUDCevap>
}